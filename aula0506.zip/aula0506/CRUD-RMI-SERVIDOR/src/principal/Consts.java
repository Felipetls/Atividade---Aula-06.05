package principal;

public class Consts {
    public static String IP_LOCAL = "127.0.0.1";
    public static String PORTA_LOCAL = "1099";
}

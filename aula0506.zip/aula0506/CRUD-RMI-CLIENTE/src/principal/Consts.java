package principal;

public class Consts {
    public static String IP_SERVIDOR = "127.0.0.1";
    public static String PORTA_SERVIDOR = "1099";
}
